# -*- coding: utf-8 -*-

"""rcr main."""

from .cli import main

if __name__ == '__main__':
    main()
